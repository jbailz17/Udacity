#Movie Trailer Website

##How to Run the Program

1. Extract the .zip file.
2. Open git bash and navigate to the extracted file's directory.
3. Once you have navigated to the "Movie Project" directory, run the below code:

   `python entertainment_center.py`
4. A web page should have been created.
5. if the page did not open automatically then navigate to the "Movie Project" file and open the .html file that is now there.
