Author: Joel Bailey
Date 13/11/2017
Purpose: Neighborhood Map Project

Instructions:

/* Open "index.html" to view the site. */

/* Google maps API was used to create the neighborhood map.
   The Wikipedia API has been used to display information in the info window. */ 
