#!/usr/bin/env python3
import query

loop = 'y'

while loop == 'y':
    print("\nEnter an integer for query selection:\n")
    try:
        choice = int(input("1. What are the most popular three articles of all"
                           "time?\n"
                           "2. Who are the most popular article authors of all"
                           "time?\n"
                           "3. On which days did more than 1% of requests lead"
                           "to errors?\n"))
        if choice == 1:
            query.query1()
        elif choice == 2:
            query.query2()
        elif choice == 3:
            query.query3()
        else:
            print("Incorrect entry, please try again:")
    except:
        print("Incorrect entry, please try again:")

    loop = input("\nWould you like to make another query? \n"
                 "'y' for yes, or any key to cancel: \n").lower()
