Author: Joel Bailey
Date: 17/10/2017
Purpose: To access a database and extract website article information

Instructions:

// Database file 'newsdata.sql' loaded within the vagrant VM with the
// command 'psql -d news -f newsdata.sql'

// A view was created called 'article_view' which is recreated in the news database.
//CREATE VIEW "article_view" AS
//        "select distinct path, count(path)
//        from log where status = '200 OK' and path != '/'
//        group by path
//        order by count(path) desc;"

// Code is used to access three specific queries upon the database:
//      * 1. What are the most popular three articles of all time?
//      * 2. Who are the most popular article authors of all time?
//      * 3. On which days did more than 1% of requests lead to errors?

// Run .py files with python3

// Start 'main.py' to access data from database, which should be in the same
// working directory. 'main.py' will call functions from 'query.py'.
