import psycopg2
import datetime

DBNAME = "news"


def query1():
    db = psycopg2.connect(database=DBNAME)
    q = db.cursor()
    q.execute("""select articles.title,
                 substring(article_view.path, 10) as slug_path,
                 article_view.count
                 from articles, article_view
                 where articles.slug = substring(article_view.path, 10)
                 order by count desc
                 limit 3;""")
    for title, path_slug, count in q.fetchall():
        print("\"{}\" - {} views".format(title, count))
    db.close()


def query2():
    db = psycopg2.connect(database=DBNAME)
    q = db.cursor()
    q.execute("""select authors.name,
                 sum(article_view.count) as total
                 from authors, articles, article_view
                 where articles.author = authors.id
                 and articles.slug = substring(article_view.path, 10)
                 group by name
                 order by total desc;""")
    for name, total in q.fetchall():
        print("{} - {} views".format(name, total))
    db.close()


def query3():
    db = psycopg2.connect(database=DBNAME)
    q = db.cursor()
    q.execute("""select date(time),
                 (sum(case when status != '200 OK' then 1.0 else 0 end)/
                 count(*)) * 100 as percent
                 from log
                 group by date(time)
                 having (sum(case when status != '200 OK' then 1.0 else 0 end)/
                 count(*)) * 100 >= 1
                 order by percent;""")
    for date, percent in q.fetchall():
        print(date.strftime('%B %d, %Y'), "- {}% errors"
              .format(round(percent, 1)))
    db.close()
